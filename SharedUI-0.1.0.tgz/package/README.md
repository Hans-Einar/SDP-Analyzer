# SharedUI Dashboard Builder User Guide

SharedUI is a schema-first React dashboard builder for internal tools.
It lets you describe a dashboard as validated configuration instead of hand-writing every page layout in JSX.

The system is designed around five explicit boundaries:

- schema and validation
- renderer and state runtime
- shared component library and tokens
- data and async runtime
- auth and authorization runtime

If you keep those boundaries clear, dashboards stay easier to understand, test, and extend.

## What SharedUI Is Good For

Use SharedUI when you want to build:

- admin panels
- operations consoles
- reporting dashboards
- planning tools
- backoffice workflows

Do not treat it as a freeform page builder.
The top-level region model is intentionally fixed so dashboards stay predictable across projects.

## Package Surface

The repository can now be built and packed as an installable npm package.
The published package includes the SharedUI runtime, schemas, shared components, styles, and docs, while excluding `src/examples` and `dev-preview`.

Package install guidance lives in:

- `docs/PACKAGE_INSTALLATION.md`

The stable import surfaces are organized by source area:

- `src/schema`: contracts, validation, presets, selectors, and state helpers
- `src/renderer`: `DashboardRenderer`, hooks, runtime helpers, and URL sync
- `src/components/baseline`: shared baseline components and `baselineComponentRegistry`
- `src/data`, `src/auth`, `src/actions`: runtime helpers for optional integrations
- `src/examples`: end-to-end reference dashboards kept in the repository only
- `dev-preview`: Vite host for browsing the examples locally, also repository only

## Mental Model

Think in this order:

1. Define your dashboard state and validators.
2. Define who owns each state key and which update sources are allowed.
3. Author views and place them into the fixed regions.
4. Register trusted components by stable string key.
5. Add optional data sources, transforms, auth adapters, and action handlers.
6. Render everything through `DashboardRenderer`.

The renderer owns layout resolution.
The schema owns structure.
The component registry owns presentation.

## Quick Start

Install dependencies:

```powershell
npm install
```

Open the preview host:

```powershell
npm run preview:dev
```

Run the main local checks:

```powershell
npm run build
npm test
npm run presets:check
```

## Minimal End-To-End Example

This is the smallest practical shape for a static dashboard.
It uses validated state, one custom component, and the shared renderer.
The import paths below assume a repo-root-oriented example for clarity, so adjust them to match the file where you place your dashboard code.

```tsx
import { baselineComponentRegistry } from "./src/components/baseline/index.js";
import { DashboardLink, DashboardRenderer } from "./src/renderer/index.js";
import { defineDashboardConfig } from "./src/schema/index.js";

type ExampleState = {
  section: "overview" | "settings";
};

const validatorRegistry = {
  section: (value: unknown): value is ExampleState["section"] =>
    value === "overview" || value === "settings",
};

function WelcomePanel() {
  return (
    <section>
      <h2>Overview</h2>
      <p>This screen is being resolved from dashboard config.</p>
      <DashboardLink set={{ section: "settings" }}>Open settings</DashboardLink>
    </section>
  );
}

const componentRegistry = {
  ...baselineComponentRegistry,
  WelcomePanel: {
    kind: "custom" as const,
    component: WelcomePanel,
  },
};

const config = defineDashboardConfig<ExampleState>({
  state: {
    section: "overview",
  },
  statePolicy: {
    section: {
      owner: "navigation",
      allowedUpdateSources: ["link", "public-navigation", "url"],
      validatorKey: "section",
      defaultValue: "overview",
    },
  },
  layout: {
    main: {
      view: "overviewView",
      variants: {
        "section=settings": { view: "settingsView" },
      },
    },
  },
  views: {
    overviewView: {
      type: "stack",
      children: [{ kind: "component", ref: "WelcomePanel" }],
    },
    settingsView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "ContentPanel",
          props: {
            title: "Settings",
            body: "This view was selected through a region variant.",
          },
        },
      ],
    },
  },
});

export function App() {
  return (
    <DashboardRenderer
      componentRegistry={componentRegistry}
      config={config}
      validatorRegistry={validatorRegistry}
    />
  );
}
```

### What This Example Shows

- `defineDashboardConfig(...)` gives you a typed schema authoring surface
- `statePolicy` is required and is the gatekeeper for state changes
- regions choose named views
- variants switch views based on current state
- components are resolved by trusted string key from the registry
- `DashboardLink` participates in the renderer's public navigation flow, so navigation keys should allow public navigation updates

## The Main Building Blocks

### 1. State And State Policy

Every dashboard has a root `state` object and a matching `statePolicy`.
`statePolicy` is not optional because SharedUI needs to know:

- who owns each key
- which update sources are allowed
- which validator should be used
- which default value applies

Common owners and sources:

- navigation-owned state: user navigation and URL-driven view switching
- auth-owned state: values written by auth adapters
- view-owned state: state controlled by trusted runtime logic
- public update sources: `link`, `public-navigation`, `url`
- trusted update sources: `auth-adapter`, `action-handler`, `trusted-runtime`

If a state update comes from the wrong source, the runtime blocks it and records a warning instead of silently mutating state.

### 2. Layout And Views

SharedUI has five fixed top-level regions:

- `topBar`
- `bottomBar`
- `leftSidebar`
- `rightSidebar`
- `main`

Each configured region points at a named view.
Views contain children, and each child is either:

- another view reference
- a component reference

This gives you nested composition without losing the fixed shell structure.

### 3. Component Registry

The renderer never imports dashboard components directly.
Instead, the config refers to stable string keys such as `MetricCard` or `PageHeader`, and the registry maps those keys to React components.

Use the shared baseline registry when possible:

```ts
import { baselineComponentRegistry } from "./src/components/baseline/index.js";
```

Add custom components only when the shared library does not already cover the job.

### 4. Validation

Validation happens before rendering.
The schema layer checks:

- structure
- named view references
- component keys
- data source keys
- data transform keys
- selector syntax
- validator availability
- initial state validity

In development mode, invalid dashboards render a visible validation error instead of failing silently.

### 5. Optional Runtime Layers

You can keep a dashboard static, or you can layer in:

- data sources and transforms
- auth and RBAC
- action handlers
- URL sync
- local view state

All of these stay explicit in the config and registries.

## Working With Examples

The examples are the best source of real usage patterns:

- `staticDashboardBaseline`: auth, actions, async data, local state, protected views
- `componentLibraryShowcase`: baseline component inventory and preview surface
- `printerOperationsConsole`: realistic monitoring dashboard with async data
- `maintenancePlanner`: forms, confirmations, and action flows

Supporting example docs:

- `src/examples/README.md`
- `docs/ADOPTION_AND_MIGRATION.md`
- `src/components/baseline/COMPONENT_CONTRACTS.md`

## Common Commands

```powershell
npm run build
npm test
npm run presets:update
npm run presets:check
npm run preview:dev
npm run preview:build
```

## Presets

SharedUI supports JSON-safe dashboard presets.
Use presets when you need a serialized form of a validated config.

- `exportDashboardPreset(...)` creates JSON from a validated config
- `importDashboardPreset(...)` validates and loads preset JSON
- `npm run presets:update` regenerates the checked-in example presets
- `npm run presets:check` verifies they are still in sync

Presets must stay secret-free and JSON-safe.
Do not put tokens, credentials, or executable code into them.

## Recommended Authoring Workflow

1. Start from one of the existing examples.
2. Define validators first.
3. Write the smallest possible typed config.
4. Reuse the baseline component registry before creating custom JSX.
5. Add data, auth, actions, and URL sync only when the static dashboard shape is working.
6. Validate locally with `npm run build`, `npm test`, and preview checks.
7. Regenerate presets if your example configs changed.

## Troubleshooting

If a dashboard does not render as expected, check these first:

- every state key has a matching `statePolicy` entry
- every `validatorKey` exists in the validator registry
- every view name referenced by `layout` or `view` nodes exists
- every component key exists in the component registry
- every `fromState` reference points at dashboard state or the current view's local state
- every URL-synced state key allows the `"url"` source
- auth-owned state is not being mutated from public sources

## Where To Go Next

- Read `docs/HOW_TO_GUIDE.md` for a procedural build-from-scratch guide.
- Read `docs/ADOPTION_AND_MIGRATION.md` for migration and rollout rules.
- Read `src/components/baseline/COMPONENT_CONTRACTS.md` before adding shared components.
- Use `dev-preview` when you want a fast manual feedback loop while authoring.
