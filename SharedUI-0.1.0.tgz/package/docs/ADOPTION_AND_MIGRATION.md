# Adoption and Migration Guidance

## Schema Versioning Expectations

- The current platform contract should be treated as `v1`.
- Additive changes are preferred whenever possible.
- Any breaking schema change should update:
  - the authoritative SDP design docs
  - example dashboards
  - migration notes
  - preset compatibility guidance

## Preset Compatibility Rules

- Presets must round-trip through the same validated root schema contract as live configs.
- Presets must stay JSON-safe.
- Presets must not include:
  - auth tokens
  - refresh tokens
  - session secrets
  - executable validators or component code
- Unknown validator, component, data-source, or transform keys should fail fast during validation.

## Migration Rules

- Prefer field addition over field replacement.
- If a field must be renamed or removed, add migration notes before landing the change.
- Keep the example dashboards in sync with the latest supported schema so they act as migration sentinels.
- Re-run `npm run build` and `npm test` after any schema or preset change.

## Hardening Review

### Accessibility

Current examples verify and rely on:
- semantic navigation landmarks
- accessible headings
- tables with header cells
- searchbox and textbox semantics
- `alert`, `status`, and `alertdialog` roles where appropriate

### Error Handling

The runtime currently surfaces:
- schema validation failures
- renderer runtime warnings in development
- async error fallbacks
- blocked protected-state writes

### Performance

Large synthetic dashboards can be profiled with `profileLargeDashboardRender()` in:
- `src/examples/hardening/profileLargeDashboard.tsx`

This gives a lightweight local render profile for large view trees without changing the schema model.

## Adoption Checklist

Before broader team adoption:
- keep shared components on the baseline registry contract
- document trusted custom JSX components using the same contract headings as shared components
- add or update at least one example dashboard when new schema behavior is introduced
- keep presets round-trippable and secret-free
- keep local verification green
