# ADR-001: SharedUI Ownership Boundary for shadcn-based Standard Components

## Status

Accepted

## Date

2026-04-08

## Context

The project is building a reusable `SharedUI` package for multiple web applications that should share the same overall UX model:

- top bar
- left navigation/sidebar
- center/main content region
- right action/sidebar
- optional bottom command or status area

The system is also designed to support schema-driven or config-driven dashboard composition, where presets and dashboard configuration files describe:

- layout regions
- semantic view/component references
- state policy
- variants
- defaults
- persistence-related state

At the same time, the platform must support application-specific views and widgets that are not yet standardized across all apps.

A design question emerged:

**Should raw `shadcn/ui` source code live only inside each consumer app, or should SharedUI own some of it?**

The answer must support the actual product goal:

- consistent UX across many apps
- a standardized set of reusable UI patterns
- implementation-agnostic presets
- support for app-specific custom components
- a clean ownership boundary that avoids monolithic sprawl

This ADR formalizes the conclusion reached after review of:

- `docs/SharedUI-shadcn-architecture-note (1).md`

---

## Decision

`SharedUI` will own a **curated set of shared standard components** implemented using locally owned `shadcn/ui` source where appropriate.

`SharedUI` will **not** attempt to own all possible `shadcn/ui` components or all possible UI widgets.

Consumer applications will own:

- domain views
- data bindings
- special-purpose widgets
- application-specific custom JSX components
- experimental components that are not yet standardized

Presets, dashboard config, and renderer contracts will continue to reference **semantic SharedUI component or view ids**, not raw `shadcn/ui` primitive names.

---

## Decision Summary

The target architecture is:

```text
SharedUI
  - shell
  - runtime
  - schema contracts
  - state policy
  - persistence hooks/interfaces
  - curated shadcn-based semantic shared components

Consumer App
  - domain views
  - app-specific registries
  - data bindings
  - special widgets
  - custom JSX components
```

In short:

- `SharedUI` owns the standardized shared app-kit
- apps own the non-standardized or domain-specific surfaces
- presets stay semantic and implementation-agnostic

---

## Rationale

This approach is the best fit for the intended platform direction.

### Why not "all shadcn in each app only"

That model gives strong app isolation, but it works against the stated goal of a standardized shared UI layer.

If every app must decide independently which raw shadcn components to use for common patterns, then:

- UX consistency becomes weaker
- teams must rediscover the same decisions repeatedly
- the shared shell becomes thinner than intended
- the shared component layer provides less practical value

That is not the desired outcome for this project.

### Why not "put everything into SharedUI"

That would create the opposite failure mode:

- SharedUI becomes too large
- SharedUI becomes a dumping ground for all widgets
- domain-specific components leak into the shared layer
- maintenance and versioning become harder
- application flexibility decreases

That is also not the desired outcome.

### Why the curated shared subset is the right compromise

A curated subset provides:

- a strong standardized UX baseline
- reuse of implementation and styling decisions
- a clear shared vocabulary of semantic components
- freedom for apps to supply special widgets when needed
- a path for promotion of proven app-specific components into SharedUI later

This preserves both reuse and architectural discipline.

---

## What SharedUI Owns

`SharedUI` owns the shared platform concerns:

- application shell
- layout regions and placement logic
- runtime orchestration
- schema/config contracts
- state policy engine
- persistence interfaces/hooks
- semantic component registry contracts
- curated semantic shared components

Examples of SharedUI-owned semantic components may include:

- `TopNav`
- `SideNav`
- `PageHeader`
- `FilterPanel`
- `ActionPanel`
- `DialogShell`
- `ConfirmDialog`
- `DataTable`
- `FormScaffold`
- `EmptyState`
- `ErrorFallback`

These are exported and consumed as **semantic platform components**, not as raw shadcn primitives.

---

## What Consumer Apps Own

Consumer applications own the app-specific layer:

- domain views
- view composition for business entities
- API/data bindings
- app-specific registries
- special-purpose or experimental widgets
- custom JSX components
- domain-only actions and interaction models

Examples may include:

- `CustomersView`
- `OrdersView`
- `ProductsView`
- `CodexSessionView`
- `AgroTable`
- `LeafletMapView`
- `PlotlyChartView`
- `TopologyCanvas`
- `ConsoleTranscriptPanel`

These stay outside SharedUI unless they later prove broadly reusable.

---

## Preset and Schema Rule

Presets must remain implementation-agnostic.

That means:

- presets reference semantic component/view ids
- presets do not encode raw shadcn primitive names
- presets do not encode React implementation details
- presets do not care whether a semantic component is implemented using shadcn, custom JSX, Leaflet, Plotly, or another internal detail

This rule remains unchanged.

Example:

```json
{
  "layout": {
    "topBar": { "view": "topBarView" },
    "leftSidebar": { "view": "filtersView" },
    "main": { "view": "customersView" },
    "rightSidebar": { "view": "customerActionsView" }
  }
}
```

The preset describes semantic placement only.

---

## SharedUI and shadcn Rule

The rule is **not**:

> put all shadcn components into SharedUI

The rule is:

> SharedUI may own the locally copied shadcn-based source for the curated standard components it has chosen to standardize.

That means:

- SharedUI may wrap and compose shadcn components internally
- SharedUI should expose semantic components outward
- raw shadcn source inside SharedUI is an internal implementation detail, not the public contract
- SharedUI should not leak raw shadcn primitive contracts into presets
- SharedUI should not mirror the entire shadcn catalog without a clear need

---

## Promotion Rule for App-specific Components

Applications may register trusted custom JSX components for specialized needs.

If a custom component later proves:

- broadly reusable
- stable in purpose
- aligned with the standard UX direction
- valuable across multiple apps

then it may be promoted into SharedUI.

Promotion is optional and deliberate, not automatic.

---

## Preview Host Rule

The preview host should evolve toward behaving like a real consumer app.

That means it should:

- consume SharedUI through the same public surface expected by downstream apps
- prove the semantic component model
- prove mixed usage of SharedUI components and app-specific custom components
- verify that presets remain valid while implementation details remain hidden

This helps the preview environment validate the real adoption model, not just an internal prototype model.

---

## Code Generation and Tooling Rule

Automation is encouraged, but it should happen at **build time** or **scaffold time**, not runtime.

Examples of acceptable tooling:

- schema validation
- dashboard registry generation
- typed contract generation
- component scaffolding
- import-map generation
- optional synchronization of approved standard component wrappers

Avoid runtime downloading or runtime installation of UI component code in the browser application.

---

## Consequences

### Positive consequences

- strong shared UX baseline
- better reuse across apps
- less repeated decision-making in each app
- stable semantic contracts
- implementation-agnostic presets
- room for app-specific innovation
- clean path to promote proven widgets into the shared layer

### Negative consequences / tradeoffs

- SharedUI now carries some UI implementation responsibility
- component ownership must be reviewed carefully to avoid sprawl
- maintainers must decide what belongs in the curated shared subset
- there is still some duplication risk for app-specific widgets that are not yet promoted

These tradeoffs are acceptable.

---

## Guardrails

To keep this decision healthy, the following guardrails apply:

1. SharedUI must own a **curated** subset, not everything.
2. SharedUI must export **semantic** components, not raw shadcn primitives as the main contract.
3. Presets must remain implementation-agnostic.
4. Apps must remain free to register app-specific custom components.
5. Promotion of app-specific widgets into SharedUI must be deliberate.
6. Build-time automation is preferred over runtime code loading.
7. SharedUI should prioritize shell, composition, state, and standard UX patterns over unbounded widget growth.
8. Raw shadcn source files that SharedUI owns remain internal implementation detail unless SharedUI explicitly decides to expose a semantic wrapper around them.

---

## Practical Guidance for Sprint Planning

When evaluating a component, classify it as one of:

1. **Shared semantic standard component**
   - belongs in SharedUI
   - standardized across apps
   - often implemented with local shadcn-based source inside SharedUI

2. **SharedUI semantic wrapper/composition**
   - belongs in SharedUI
   - composed from lower-level primitives
   - still exported semantically

3. **App-specific special widget**
   - belongs in the consumer app
   - may be registered as trusted custom JSX
   - not yet standardized

4. **Promotion candidate**
   - starts in an app
   - later moves into SharedUI if reuse justifies it

This classification should guide backlog and sprint decisions.

---

## Final Architecture Statement

**SharedUI owns the shared application shell, runtime, schema contracts, persistence interfaces, and a curated set of shadcn-based semantic standard components. Consumer apps own their domain views, data bindings, and special-purpose widgets, and register those into SharedUI without exposing raw shadcn primitives in presets.**
