# Cross-Project SharedUI Gap Analysis

**Date:** 2026-04-06  
**Purpose:** identify what the current `SharedUI` project is still missing if it is going to become a practical shared UI foundation across:

- `C:\Users\hanse\GIT\agro-crm`
- `C:\Users\hanse\GIT\CodexRemote`
- `C:\Users\hanse\GIT\kinsim`
- `C:\Users\hanse\GIT\timberdata`

This document does **not** assume that future apps should look exactly like the current apps.
The goal is similar behavior and similar UX outcomes, but rebuilt on top of a cleaner shared platform.

## Current SharedUI Baseline

SharedUI is already strong in these areas:

- schema-first dashboard composition
- fixed top-level regions
- validated config and state policy
- reusable renderer runtime
- component registry model
- action/data/auth integration points
- example dashboards and preset workflow

SharedUI is still relatively early in these areas:

- shell ergonomics for advanced app workbenches
- nested resizable-pane experiences
- route-aware multi-page shells
- complex modal/overlay workflows
- richer table/form/grid primitives
- map/canvas/IDE-style workspace support
- app-level auth UX
- production-ready packaging and release flow

## Project: agro-crm

### Current app shape

The `agro-crm` web app already behaves like a shell-driven operations product.
Important patterns in `apps/web`:

- top bar with many primary modes
- left sidebar, center main panel, right actions panel
- tab registry with `Sidebar`, `Main`, and `Actions` components per mode
- multiple portals:
  - staff
  - customer portal
  - production portal
- strong role and permission awareness
- live notifications and state-health/debug surfaces
- mapping, terrain, route-planning, invoice preview, and production workflows

### What SharedUI already matches

- fixed top-level regions map well to the Agro CRM shell
- mode-based composition maps well to SharedUI views and variants
- dashboard state can model current mode, report section, seller/year/cut filters, and portal
- custom components can host route planner, terrain, invoice, and portal-specific widgets

### What SharedUI is missing for agro-crm

- first-class multi-portal shell support
  - one app needs staff, customer, and production experiences under one umbrella
- permission-aware navigation and view gating beyond simple role checks
  - some screens are permission slices, not only whole-role slices
- better global-context controls
  - year, cut, company, seller, and portal context behave like top-shell state, not just per-view filters
- richer shared table patterns
  - grouped rows, totals, expandable rows, inline edit state, billing locks, and ledger-like layouts appear repeatedly
- richer form/action orchestration
  - the current app has many action panels with contextual forms, confirm/void flows, and partial edit states
- map and geospatial panel support
  - Leaflet maps, terrain overlays, field polygons, and route planning are important here
- a better modal/overlay/dialog layer
  - notifications, state health, invoice previews, portal settings, and route-planner dialogs are common
- notification and live-update primitives
  - there is real app-level notification behavior, not only inline feedback banners
- i18n-aware component contracts
  - the app uses Norwegian and English and expects translation-friendly labels and action copy
- better async job and progress surfaces
  - terrain jobs and route planning want standardized progress/status panels

### Recommended SharedUI additions driven by agro-crm

- permission-aware shell navigation helpers
- grouped data-table and ledger-table primitives
- map/canvas panel adapter contracts
- modal/dialog/overlay runtime surface
- global context bar patterns
- notification center patterns
- stronger i18n hooks in the shell and baseline components

## Project: CodexRemote

### Current app shape

`CodexRemote` is not a classic dashboard.
It is closer to a browser IDE / remote operator console.

Important patterns:

- conversation + workspace dual-mode layout
- resizable left and right sidebars
- nested explorer/editor split
- collapsible explorer and terminal rails
- Monaco editor, diff view, markdown preview
- terminal pane backed by `node-pty`
- Git control overlays
- project picker and project administration
- live thread streaming and activity timelines
- Google OAuth plus local allowlist/admin controls

### What SharedUI already matches

- region-based layout is still useful
- state policy and explicit runtime boundaries match the app well
- custom component registry can host file tree, editor, terminal, and conversation components

### What SharedUI is missing for CodexRemote

- IDE-style nested panel layouts
  - CodexRemote needs more than one level of resizable split behavior
- collapsible rails and workspace sub-layout persistence
- streaming activity/timeline primitives
  - this app has live thread events, not just static data loading
- better support for tool/workspace surfaces instead of business dashboards
  - file trees, code editors, diffs, and terminals are central UX elements
- secondary overlay workflows
  - branch dialogs, project picker, admin overlays, settings, session takeover
- dual focus modes
  - the app intentionally switches between conversation-focused and workspace-focused modes
- runtime capability display
  - models, reasoning effort, access modes, adapter capabilities, and usage status are top-level UX
- more advanced persistence hooks
  - current UI stores selection state, collapse state, theme, and focus mode

### Recommended SharedUI additions driven by CodexRemote

- nested split-layout primitives
- collapsible rail support
- activity stream / timeline components
- shell support for workstation-style apps, not only dashboards
- structured overlay manager
- persistent UI preferences framework
- component contracts for tree/editor/terminal/canvas style content hosts

## Project: kinsim

### Current app shape

`kinsim` already has an internal shared-shell proving ground:

- top bar with task tabs
- left navigator
- center workspace
- right actions panel
- persisted panel widths and collapse state
- mobile drawer behavior

Its main tabs are:

- Component Editor
- System Editor
- Transient Analysis

And the main domain widgets are:

- topology editor with React Flow and ELK
- component-library editor
- trace plotting
- collector/drain panels
- playback controls

### What SharedUI already matches

- very strong conceptual match on navigator/main/actions regions
- workbench tabs map naturally to SharedUI state + region variants
- custom components can host the Kinsim domain widgets without forcing them into the baseline library

### What SharedUI is missing for kinsim

- panel width persistence and collapse state per tab
- mobile drawer behavior for side regions
- bottom-bar or auxiliary playback region support as a first-class pattern
- support for very large custom canvas/workspace components
- standardized shell state persistence
- better handling of locally-owned rich state that should not all be pushed into top-level dashboard state
- workbench-friendly layout presets

### Recommended SharedUI additions driven by kinsim

- region presentation state
  - collapsed, hidden, width hints, mobile drawer mode
- shell-persistence adapters
- better support for custom canvas and simulation workspaces
- bottom status/playback region patterns

## Project: timberdata

### Current app shape

`timberdata` is structurally simpler than the others, but it already uses a clear page shell:

- top brand/status/navigation panel
- page-level navigation/main/actions layout
- route-like page switching
- document preview overlays
- data-heavy review screens
- admin access page
- import workflow

Its main screens include:

- import
- measure receipts
- settlements
- projects
- statistics
- admin

### What SharedUI already matches

- the shell shape fits SharedUI very naturally
- route/page state can map cleanly to SharedUI dashboard state
- the current page-shell decomposition is already close to region-based composition

### What SharedUI is missing for timberdata

- route/page shell patterns for simple multi-page business apps
- stronger document preview overlay support
- better metric-card + detail-table + compare-table baseline surfaces
- chart and trend visualization wrappers
- auth-gated shell and admin-mode patterns
- a simple navigation-page-action composition recipe for apps that are lighter than agro-crm but more structured than a demo

### Recommended SharedUI additions driven by timberdata

- small-business app shell starter
- document preview overlay pattern
- trend/chart wrapper contracts
- auth-gated page shell recipes
- admin page and access-management shell patterns

## Cross-Project Summary

Across all four projects, SharedUI needs to evolve in three layers.

### Layer 1: Core shell maturity

These are the most universally useful additions:

- region presentation state
  - collapsed, hidden, width hints, drawer mode
- stronger shell persistence
  - remember panel state, active view, shell preferences
- better overlay/runtime management
  - dialogs, drawers, previews, admin overlays, notifications
- route/page-level composition patterns
  - for apps that are not single dashboards

### Layer 2: Shared business-app primitives

These appear in both `agro-crm` and `timberdata`, and partly in `kinsim`:

- grouped/expandable tables
- ledger/table variants with summary rows
- richer action-panel forms
- notification and status surfaces
- chart wrappers
- document preview surfaces
- auth-aware account and access UI hooks

### Layer 3: Advanced workspace adapters

These are important for `CodexRemote` and `kinsim`, and partly useful elsewhere:

- nested split-pane layouts
- collapsible rails
- custom canvas/map/editor host components
- streaming activity/timeline surfaces
- large-workspace UX patterns

## Suggested SharedUI Strategy

Do **not** try to turn SharedUI into a giant bag of project-specific widgets.

Instead, build SharedUI in three rings:

### Ring A: Stable platform core

- schema
- renderer
- state policy
- auth/action/data integration points
- shell regions
- persistence hooks
- overlay manager

### Ring B: shared baseline app-kit

- table variants
- forms
- metric cards
- navigation patterns
- account menus
- dialogs
- chart wrappers
- notification center

### Ring C: adapter surfaces

- map/canvas host contract
- IDE/workspace host contract
- simulation/workbench host contract
- document preview contract

This lets each project keep its rich domain-specific components while still converging on one shared shell, one shared runtime model, and one shared UX vocabulary.

## Recommended Next Moves

1. Make SharedUI package-ready so other repos can consume it cleanly.
2. Add region presentation state and shell persistence first.
3. Add overlays, dialogs, and notifications second.
4. Add grouped-table and action-panel improvements third.
5. Treat maps, editors, terminals, and simulation canvases as adapter-host surfaces, not baseline components.
