# SharedUI How-To Guide

This is the practical guide for building with SharedUI in this repository.
Use it together with:

- `AGENTS.md`
- `docs/ADR-001-SharedUI-Ownership-Boundary.md`
- `docs/PACKAGE_INSTALLATION.md`
- `docs/SharedUI-Schema-Driven-Directive-for-Codex-v2.md`
- `src/examples/README.md`

If you only remember one rule, remember this:

**SharedUI consumer pages must be schema-driven by default.**

That means:

- page structure is declared in dashboard config and optional preset
- SharedUI owns the rendering logic and semantic component surface
- SharedUI may internally use shadcn, but consumer configs must not treat raw shadcn primitives as the public authoring surface
- app-specific JSX is allowed for trusted custom widgets, but it must be mounted through the SharedUI registry/runtime system

## 1) What SharedUI Owns

SharedUI owns:

- schema contracts and validation
- renderer and state runtime
- semantic shared component ids
- shell and region rendering behavior
- locally owned shadcn-based implementation of shared semantic components

Consumer apps or examples own:

- dashboard config and optional preset
- validators
- data sources
- action handlers
- trusted custom widgets that SharedUI does not yet standardize

Examples of SharedUI-owned semantic refs:

- `TopNav`
- `SideNav`
- `PageHeader`
- `DataTable`
- `ConfirmDialog`

Examples of app-owned custom widgets:

- `PlannerSummary`
- `PressureStatusStrip`
- `AgroTable`

## 2) What Consumer Code Must Not Do

When using SharedUI, do not make direct page JSX the primary composition path.

That means do not:

- hand-build the full page shell in one React component
- compose `topBar`, `leftSidebar`, `main`, `rightSidebar`, and `bottomBar` directly in app code as the main pattern
- use raw shadcn primitive names as the consumer-facing page language
- bypass `DashboardRenderer`
- bypass `statePolicy`
- fetch async data directly inside page-shell components when the same flow should be expressed through registered `dataSources.ts`

Direct JSX is still acceptable for:

- app-owned custom widgets
- small leaf implementation details
- SharedUI internals

## 3) The Standard SharedUI Consumer Surface

A normal SharedUI consumer app or example should usually provide:

- `dashboardConfig.ts`
- `componentRegistry.tsx`
- `validatorRegistry.ts`
- `dataSources.ts` when async data is used
- `actionHandlers.ts` when forms/dialog actions are used
- `dashboardPreset.json` when the repo workflow expects presets

These are the files that describe and attach the app to SharedUI.

## 4) Using SharedUI As A Package

There are two common ways to work with SharedUI:

- **inside this repository**
  - import from repo-local source paths like `src/schema`, `src/renderer`, and `src/components/baseline`
- **from another app as an installed package**
  - install `SharedUI`
  - import from the package entrypoints instead of repo-local paths

If the package has not been published to an npm registry yet, install it from the local tarball:

```powershell
npm install C:\path\to\SharedUI-0.1.0.tgz
```

If it has been published, install it normally:

```powershell
npm install SharedUI
```

Consumer app requirements:

- your app must provide `react`
- your app must provide `react-dom`
- import the SharedUI CSS once in your app entry

```ts
import "SharedUI/styles.css";
```

Important package note:

- the published package does **not** include `src/examples/` or `dev-preview/`
- the examples in this repository are reference implementations, not files that ship inside the npm package
- `src/examples/agroCrmLive/` is a strong example of the SharedUI authoring model, but inside this repo it imports SharedUI source directly rather than consuming the installed package artifact

## 5) How The System Fits Together

Think about the system in this order:

1. define state and validators
2. define `statePolicy`
3. define `layout`
4. define `views`
5. mount semantic shared components or trusted custom components by string ref
6. register data sources and action handlers
7. render through `DashboardRenderer`

SharedUI then resolves the structure like this:

- schema chooses the active region views
- views choose child nodes
- child nodes reference semantic components or nested views
- SharedUI renders the result

So the split is:

- schema decides **what appears where**
- SharedUI decides **how the semantic surface renders**
- app-owned JSX implements only the custom leaf widgets that SharedUI does not own

## 6) The Fixed Region Model

SharedUI uses a fixed set of top-level layout regions:

- `topBar`
- `leftSidebar`
- `main`
- `rightSidebar`
- `bottomBar`

The region model is intentionally fixed.
Do not invent new top-level regions in consumer code unless the design documents change.

## 7) Step-By-Step Build Flow

### Step 1: Define State And Validators

Write the state shape first.
That forces you to decide what the dashboard actually needs.

```ts
type PlannerState = {
  section: "overview" | "jobs" | "settings";
  selectedJobId?: string;
};

const validatorRegistry = {
  section: (value: unknown): value is PlannerState["section"] =>
    value === "overview" || value === "jobs" || value === "settings",
  selectedJobId: (value: unknown): value is PlannerState["selectedJobId"] =>
    value === undefined || typeof value === "string",
};
```

### Step 2: Define `statePolicy`

Every top-level state key needs a `statePolicy` entry.

```ts
statePolicy: {
  section: {
    owner: "navigation",
    allowedUpdateSources: ["link", "public-navigation", "url"],
    validatorKey: "section",
    defaultValue: "overview",
  },
  selectedJobId: {
    owner: "view",
    allowedUpdateSources: ["trusted-runtime", "action-handler"],
    validatorKey: "selectedJobId",
  },
}
```

### Step 3: Start With SharedUI Semantic Components

Begin with the shared registry.

If you are consuming the installed package:

```ts
import { baselineComponentRegistry } from "SharedUI/components/baseline";
```

If you are working inside this repository:

```ts
import { baselineComponentRegistry } from "../components/baseline/index.js";

const componentRegistry = {
  ...baselineComponentRegistry,
};
```

Add custom components only when the shared semantic surface does not already cover the need:

```ts
const componentRegistry = {
  ...baselineComponentRegistry,
  PlannerSummary: {
    kind: "custom" as const,
    component: PlannerSummary,
  },
};
```

### Step 4: Author `dashboardConfig.ts`

This is the typed authoring surface.

If you are consuming the installed package:

```ts
import { defineDashboardConfig } from "SharedUI/schema";
```

If you are working inside this repository:

```ts
import { defineDashboardConfig } from "../schema/index.js";

export const plannerConfig = defineDashboardConfig<PlannerState>({
  state: {
    section: "overview",
  },
  statePolicy,
  layout: {
    topBar: { view: "topBarView" },
    leftSidebar: { view: "sideNavView" },
    main: {
      view: "overviewView",
      variants: {
        "section=jobs": { view: "jobsView" },
        "section=settings": { view: "settingsView" },
      },
    },
  },
  views: {
    topBarView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "TopNav",
          props: {
            title: "Maintenance Planner",
            subtitle: "SharedUI example",
          },
        },
      ],
    },
    sideNavView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "SideNav",
          props: {
            items: [
              { label: "Overview", set: { section: "overview" } },
              { label: "Jobs", set: { section: "jobs" } },
              { label: "Settings", set: { section: "settings" } },
            ],
          },
        },
      ],
    },
    overviewView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "PageHeader",
          props: { title: "Overview" },
        },
      ],
    },
    jobsView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "PageHeader",
          props: { title: "Jobs" },
        },
      ],
    },
    settingsView: {
      type: "stack",
      children: [
        {
          kind: "component",
          ref: "ContentPanel",
          props: {
            title: "Settings",
            body: "Author settings here.",
          },
        },
      ],
    },
  },
});
```

### Step 5: Render Through `DashboardRenderer`

If you are consuming the installed package:

```tsx
import { DashboardRenderer } from "SharedUI/renderer";
```

If you are working inside this repository:

```tsx
import { DashboardRenderer } from "../renderer/index.js";

export function PlannerApp() {
  return (
    <DashboardRenderer
      componentRegistry={componentRegistry}
      config={plannerConfig}
      validatorRegistry={validatorRegistry}
    />
  );
}
```

This is the required composition engine.
If your page shell is not going through `DashboardRenderer`, you are outside the intended SharedUI model.

## 8) `dashboardConfig.ts` vs `dashboardPreset.json`

### `dashboardConfig.ts`

This is the typed source of truth for authoring.
It normally contains:

- `state`
- `statePolicy`
- `layout`
- `views`
- defaults
- optional auth or URL sync

### `dashboardPreset.json`

This is the serialized validated representation.
It exists for:

- portability
- validation
- round-tripping
- proving implementation-agnostic structure

The preset must stay semantic and implementation-agnostic.
It must not encode:

- raw shadcn primitive names
- copied implementation details
- secrets or environment material

## 9) How To Add Async Data

### Step 1: Register Data Sources

```ts
const dataSourceRegistry = {
  plannerApi: {
    fetch: async (query) => {
      if (query === "jobs/list") {
        return [
          { id: "job-1", name: "Pump inspection", status: "Queued" },
          { id: "job-2", name: "Valve replacement", status: "Scheduled" },
        ];
      }

      throw new Error(`Unsupported query: ${query}`);
    },
  },
};
```

### Step 2: Bind Data In A Component Node

```ts
{
  kind: "component",
  ref: "DataTable",
  props: {
    title: "Jobs",
    columns: ["name", "status"],
  },
  data: {
    source: "plannerApi",
    query: "jobs/list",
    cache: {
      strategy: "stale-while-revalidate",
      ttl: 60,
    },
  },
  loader: "TableSkeleton",
  error: "ErrorFallback",
}
```

### Step 3: Pass The Registry To The Renderer

```tsx
<DashboardRenderer
  componentRegistry={componentRegistry}
  config={plannerConfig}
  dataSourceRegistry={dataSourceRegistry}
  validatorRegistry={validatorRegistry}
/>
```

Important:

- the schema references a data source key, not an inline fetch implementation
- fetch logic stays out of the schema itself

## 10) How To Add Auth

Use auth through config and adapter, not by hand-building page gates into the page shell.

### Auth state

```ts
type AuthState = {
  role?: "viewer" | "admin";
  section: "overview" | "settings";
};
```

### `statePolicy`

```ts
statePolicy: {
  role: {
    owner: "auth",
    allowedUpdateSources: ["auth-adapter"],
    validatorKey: "role",
  },
  section: {
    owner: "navigation",
    allowedUpdateSources: ["link", "public-navigation", "url"],
    validatorKey: "section",
    defaultValue: "overview",
  },
}
```

### Auth config

```ts
auth: {
  provider: "passthrough",
  rbac: {
    roleStateKey: "role",
    roles: ["viewer", "admin"],
  },
  unauthenticatedView: "loginView",
  unauthorizedView: "unauthorizedView",
}
```

### Protected view

```ts
settingsView: {
  type: "stack",
  requiredRole: "admin",
  children: [
    {
      kind: "component",
      ref: "ContentPanel",
      props: {
        title: "Admin settings",
        body: "...",
      },
    },
  ],
}
```

### Auth adapter

```ts
const authAdapter = {
  initialize: async () => ({
    authenticated: true,
    stateUpdates: { role: "admin" },
  }),
};
```

Then pass it to the renderer:

```tsx
<DashboardRenderer
  authAdapter={authAdapter}
  componentRegistry={componentRegistry}
  config={plannerConfig}
  validatorRegistry={validatorRegistry}
/>
```

## 11) How To Add Actions

Keep actions explicit and trusted.

```ts
const actionHandlerRegistry = {
  savePlannerSettings: {
    run: async () => ({
      ok: true,
      stateUpdates: {
        section: "overview",
      },
    }),
  },
};
```

Use them from:

- `FormBlock`
- `ConfirmDialog`
- `ActionPanel`
- or custom components via `useDashboardAction(...)`

## 12) How To Add URL Sync

```ts
urlSync: {
  history: "replace",
  stateKeys: ["section"],
}
```

Rules:

- each URL-synced key must exist in `statePolicy`
- each URL-synced key must allow `"url"` updates
- the browser adapter must be passed to the renderer

## 13) How To Work With Custom Widgets

Custom widgets are allowed.
They must not become the full page-composition language.

The right pattern is:

- SharedUI semantic components own the shell and standard surfaces
- app-owned custom widgets fill the non-standard gaps
- custom widgets mount through `componentRegistry.tsx`

Example:

```ts
const componentRegistry = {
  ...baselineComponentRegistry,
  AgroTable: {
    kind: "custom" as const,
    component: AgroTable,
  },
};
```

Then mount it from schema:

```ts
{
  kind: "component",
  ref: "AgroTable",
  props: {
    title: "Inventory",
  },
}
```

## 14) How To Work With Presets

Use presets when you need a serialized validated representation of a dashboard.

If you are consuming the installed package:

```ts
import { exportDashboardPreset, importDashboardPreset } from "SharedUI/schema";
```

If you are working inside this repository:

```ts
import { exportDashboardPreset, importDashboardPreset } from "../schema/index.js";
```

Repository commands:

```powershell
npm run presets:update
npm run presets:check
```

## 15) Verification

If you are maintaining SharedUI inside this repository, run these from the repo root:

```powershell
npm run build
npm test
npm run presets:check
npm run preview:build
npm run package:build
npm run package:pack:dry-run
```

Use `npm run preview:dev` for normal preview work.
Use `npm run agrocrm:dev` only for the dedicated Agro CRM live path.

If you are consuming SharedUI from another app, your verification should focus on your own app build/test flow plus one manual check that:

- SharedUI CSS is imported
- `DashboardRenderer` mounts successfully
- your validator, registry, and data-source wiring resolves without runtime errors

## 16) Which Examples To Copy

Best current schema-driven starting points:

- `src/examples/staticDashboardBaseline`
- `src/examples/componentLibraryShowcase`
- `src/examples/printerOperationsConsole`
- `src/examples/maintenancePlanner`
- `src/examples/agroCrmLive`

Use these as structural references before inventing a new consumer pattern.

Important:

- the examples above are repository references
- they show how to structure a SharedUI consumer
- they do not show package imports by default because they live inside the SharedUI repo

## 17) Common Mistakes

### Mistake 1: Hand-Building The Page Shell

Wrong:

- one big React page component owns top bar, sidebars, main area, auth gate, and routing itself

Correct:

- define the shell in `dashboardConfig.ts`
- render through `DashboardRenderer`

### Mistake 2: Using Raw shadcn As The Consumer Surface

Wrong:

- consumer config or page logic treats `Dialog`, `Sidebar`, `Tabs`, or other raw shadcn primitives as the page language

Correct:

- consumers reference semantic SharedUI refs
- SharedUI hides shadcn inside its owned semantic implementation

### Mistake 3: Putting Fetch Logic In The Schema

Wrong:

- schema includes inline fetch behavior or endpoint logic

Correct:

- schema references a data source key
- fetch logic lives in `dataSources.ts`

### Mistake 4: Skipping Validators Or `statePolicy`

If a top-level state key does not have both:

- a validator
- a `statePolicy` entry

then the dashboard is incomplete in SharedUI terms.

### Mistake 5: Treating Repo Examples As Published Package Files

Wrong:

- copying imports like `../../schema/contracts.js` into another app that installed the npm package

Correct:

- in another app, import from the package entrypoints such as:
  - `SharedUI`
  - `SharedUI/schema`
  - `SharedUI/renderer`
  - `SharedUI/components/baseline`

## 18) Recommended Reading Order

1. `README.md`
2. `AGENTS.md`
3. `docs/PACKAGE_INSTALLATION.md`
4. `docs/ADR-001-SharedUI-Ownership-Boundary.md`
5. `docs/SharedUI-Schema-Driven-Directive-for-Codex-v2.md`
6. `src/examples/README.md`
7. `src/components/baseline/COMPONENT_CONTRACTS.md`
