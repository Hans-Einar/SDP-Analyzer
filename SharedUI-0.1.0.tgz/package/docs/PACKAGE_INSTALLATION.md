# SharedUI Package Installation

This package is intended to be installed into other React applications with:

```powershell
npm install SharedUI
```

## What The Published Package Contains

The npm package includes:

- the built SharedUI runtime under `dist/`
- the `docs/` folder
- the shared component contracts markdown at `src/components/baseline/COMPONENT_CONTRACTS.md`

The npm package does **not** include:

- `src/examples/`
- `dev-preview/`
- test files

## Required Peer Dependencies

Your consuming app must provide:

- `react`
- `react-dom`

## SharedUI CSS

Import the shared CSS once in your app entry:

```ts
import "SharedUI/styles.css";
```

## Main Package Entry Points

Typical imports:

```ts
import {
  DashboardRenderer,
  baselineComponentRegistry,
  defineDashboardConfig,
} from "SharedUI";
```

Subpath imports are also available:

```ts
import { DashboardRenderer } from "SharedUI/renderer";
import { baselineComponentRegistry } from "SharedUI/components/baseline";
import { defineDashboardConfig } from "SharedUI/schema";
```

Raw repo-owned shadcn surfaces are exported for advanced integration:

```ts
import { Sidebar } from "SharedUI/components/shadcn/ui/sidebar";
```

## Publishing Flow

Build the package:

```powershell
npm run package:build
```

Preview the packed contents:

```powershell
npm run package:pack:dry-run
```

Create a tarball locally:

```powershell
npm run package:pack
```
