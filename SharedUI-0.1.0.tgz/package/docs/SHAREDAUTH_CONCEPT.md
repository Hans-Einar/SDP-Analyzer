# SharedAuth Concept

**Date:** 2026-04-06  
**Purpose:** outline a conceptual `SharedAuth` system that can serve the same project set:

- `agro-crm`
- `CodexRemote`
- `kinsim`
- `timberdata`

The target is not identical login flows in every app.
The target is one shared authentication and authorization platform with app-specific presentation on top.

## Design Goal

`SharedAuth` should provide:

- a common identity model
- a pluggable authentication backend
- a reusable authorization model
- reusable session and token handling
- reusable auth UI flows where helpful
- app-specific policy configuration without rewriting the auth core

## Project: agro-crm

### Current auth needs

From the current code, `agro-crm` already wants a substantial auth system:

- PostgreSQL-backed users and password credentials
- sessions with revocation and expiry
- roles and permissions
- portal-aware access:
  - customer
  - production
  - staff
- customer-linked user accounts
- bootstrap admin support
- password reset support
- permission-aware routing and portal switching

### What SharedAuth would need to support

- first-class role + permission model
- first-class portal/access-surface model
- first-class customer or tenant linkage
- password login backend
- session cookies
- password reset
- admin user management and role editing
- per-app permission namespaces

### Agro-crm-specific note

`agro-crm` is the strongest source of requirements for the authorization model.
Its role/permission/portal structure should likely shape the SharedAuth core more than the other projects.

## Project: CodexRemote

### Current auth needs

`CodexRemote` currently uses:

- Google OAuth for app login
- allowed/admin bootstrap email lists
- server-side sessions
- admin user management
- per-project access control
- session/UI control semantics

### What SharedAuth would need to support

- OAuth provider adapters
  - Google first
  - later general OAuth/OIDC providers
- bootstrap allowlist/admin seeding
- app-level admin controls
- resource-level access rules
  - in this case, project-folder access
- user profile picture and external-profile sync
- hosted-app login gate pattern

### CodexRemote-specific note

`CodexRemote` is the strongest source of requirements for:

- external OAuth/OIDC login
- resource-level access grants
- admin allowlist flows

## Project: kinsim

### Current auth needs

`kinsim` currently has no meaningful auth layer in the same way as the others.
Its future likely needs are lighter:

- protected internal access
- maybe engineering-team-only login
- maybe role-based access later for simulation editing vs read-only review

### What SharedAuth would need to support

- simple app gate
- optional read-only vs editor roles
- easy no-auth / local-dev mode

### Kinsim-specific note

`kinsim` should not drive SharedAuth complexity.
It should benefit from SharedAuth later through simple app-level access control.

## Project: timberdata

### Current auth needs

`timberdata` already overlaps heavily with `agro-crm` auth:

- PostgreSQL-backed password login
- app access permission
- app admin permission
- inherited access from shared roles
- app-specific permission overrides
- user admin panel
- shared-admin relationship with `agro-crm`

### What SharedAuth would need to support

- multi-app permission namespaces
- inherited vs direct permission grants
- app-specific access flags layered on top of a shared user store
- admin view for per-app access control

### Timberdata-specific note

`timberdata` is the strongest source of requirements for:

- one shared identity store serving multiple applications
- app-specific access overlays on top of shared roles

## Cross-Project SharedAuth Requirements

Across the projects, SharedAuth should support five concerns.

### 1. Identity providers

SharedAuth should support multiple login backends:

- local password auth backed by PostgreSQL
- OAuth / OIDC providers
  - Google first
  - extensible to other providers later
- possible future custom external provider integration

### 2. Shared user model

A shared user should have a stable core shape:

- user id
- email
- display name
- status
- profile metadata
- auth provider links
- preferences

Optional links:

- customer id
- tenant/company ids
- app-specific profile metadata

### 3. Authorization model

SharedAuth should separate:

- identity
- app membership
- roles
- permissions
- resource-level grants

Recommended hierarchy:

1. global user
2. app access
3. app roles
4. app permissions
5. resource grants

Examples:

- agro-crm portal access
- timberdata app access
- CodexRemote project-folder access

### 4. Sessions and login UX

SharedAuth should provide reusable support for:

- cookie-based sessions
- session expiry and revocation
- password reset
- account menu data
- login/logout endpoints
- "who am I" endpoint
- admin user management endpoints

Optional future support:

- magic link login
- MFA
- device/session listing

### 5. Shared auth UI kit

Not every app needs the same auth screens, but SharedAuth should probably expose reusable UI building blocks:

- login form
- OAuth sign-in buttons
- forgot/reset password flows
- account menu
- session/status chip
- access denied / login required shells
- admin user access tables

## Proposed SharedAuth Architecture

## Layer A: SharedAuth Core

Owns:

- user identities
- provider links
- sessions
- password credentials
- password reset tokens
- role and permission resolution
- resource grant resolution

## Layer B: SharedAuth Adapters

Owns provider integrations:

- password/PostgreSQL adapter
- Google OAuth adapter
- future OIDC adapter

## Layer C: App policy packages

Each app defines:

- its permission namespace
- its role mapping
- its app access rules
- optional resource grant types

Examples:

- `agro-crm` app policy
- `timberdata` app policy
- `codexremote` app policy

## Layer D: SharedAuth UI

Reusable frontend pieces for:

- auth gates
- login pages
- account menu
- admin user access views

## Suggested First Scope

The safest first SharedAuth scope is:

1. shared PostgreSQL-backed identity store
2. password login
3. Google OAuth adapter
4. sessions and logout
5. shared user/role/permission schema
6. app access + resource access hooks

This would already cover:

- agro-crm
- timberdata
- CodexRemote

`kinsim` could consume it later with almost no extra complexity.

## Recommended Data Model Direction

Suggested core entities:

- users
- auth_providers
- auth_provider_accounts
- password_credentials
- sessions
- password_reset_tokens
- apps
- app_memberships
- roles
- role_permissions
- permission_overrides
- resource_grants

This is intentionally app-aware.
It should not be only a raw login system.

## Recommended SharedAuth Strategy

Do **not** make SharedAuth only a wrapper around one auth provider.

Make it:

- provider-pluggable for authentication
- policy-driven for authorization
- app-aware for multi-project access

That gives you:

- one user identity foundation
- one session model
- one admin access model
- multiple app behaviors on top

## Recommended Next Moves

1. Normalize the shared user/session/permission vocabulary across `agro-crm`, `timberdata`, and `CodexRemote`.
2. Design SharedAuth around PostgreSQL identity + provider adapters.
3. Start with password auth and Google OAuth.
4. Make app access and resource grants first-class from day one.
5. Keep app-specific role definitions in app policy modules, not hardcoded into the auth core.
