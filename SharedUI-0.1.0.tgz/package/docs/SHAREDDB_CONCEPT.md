# SharedDB Concept

**Date:** 2026-04-06  
**Purpose:** outline a conceptual `SharedDB` system for the same project set:

- `agro-crm`
- `CodexRemote`
- `kinsim`
- `timberdata`

The name `SharedDB` is useful shorthand, but the concept should probably be a **shared data platform**, not one universal schema.

## Design Goal

`SharedDB` should help standardize:

- database configuration
- migrations
- common infrastructure tables
- storage adapters
- read-model and projection patterns
- document/file metadata handling
- backup/export/import utilities

It should **not** force all projects into one shared business schema.

## Project: agro-crm

### Current data/storage shape

`agro-crm` already has the most mature shared-storage direction:

- workspace package structure
- storage package with JSON and PostgreSQL backends
- event-store and read-model concepts
- PostgreSQL config and migration support
- auth tables and business tables in PostgreSQL
- outbox/notifications and route-planning/terrain job data on the server side

### What SharedDB should learn from agro-crm

- backend adapters matter
  - JSON for bootstrap/dev
  - PostgreSQL for production
- migration tooling matters
- read-model building matters
- projection/export/import tooling matters
- auth data and app data must coexist cleanly

### What SharedDB would still need beyond agro-crm

- more formal shared migration runner
- reusable schema namespaces by subsystem
- reusable job/outbox tables
- reusable audit/event metadata
- reusable file/document registry patterns

## Project: CodexRemote

### Current data/storage shape

`CodexRemote` uses database-backed app state for:

- project registry
- auth store
- UI state
- project activity
- access-control relationships

It is a host utility app, so its data is app-control data rather than business-ledger data.

### What SharedDB should learn from CodexRemote

- lightweight app metadata stores are important
- not every app needs a full business database
- SQLite or a small embedded database can be the right default for utility apps
- UI/session/project-control state deserves first-class persistence patterns

### What SharedDB would need for CodexRemote

- embedded-db support
  - SQLite class of use case
- shared migration/versioning even for small local databases
- standard state-store tables for:
  - sessions
  - preferences
  - project registry
  - access grants

## Project: kinsim

### Current data/storage shape

`kinsim` is still lighter on server/database infrastructure.
It relies more on:

- local browser state
- seeded JSON/domain configuration
- save files and library definitions

### What SharedDB should learn from kinsim

- not every project begins with a server database
- local-first data and file-backed persistence are still important
- config, presets, and authored assets are often as important as records in tables

### What SharedDB would need for kinsim

- simple file-backed or embedded-db options
- versioned preset/config storage helpers
- migration/version helpers for local data
- optional sync-to-Postgres later, not required from day one

## Project: timberdata

### Current data/storage shape

`timberdata` currently has:

- a JSON-backed canonical store
- derived view files
- import pipeline from source documents
- project/receipt/settlement read-model building
- PostgreSQL-backed auth store

This is a very strong signal that app data and auth data may evolve at different speeds.

### What SharedDB should learn from timberdata

- document import pipelines need first-class support
- canonical store + derived views is a useful pattern
- file metadata and source-document lineage matter
- apps may start JSON-first but want a later PostgreSQL path

### What SharedDB would need for timberdata

- reusable document registry schema
- reusable import-run tracking
- reusable projection/read-model helpers
- migration path from JSON store to PostgreSQL

## Cross-Project SharedDB Requirements

Across the projects, SharedDB should likely serve four different classes of persistence.

### 1. App metadata stores

Needed strongly by:

- CodexRemote
- SharedAuth itself

Examples:

- users
- sessions
- UI state
- project registry
- resource grants

### 2. Business or domain data stores

Needed strongly by:

- agro-crm
- timberdata

Examples:

- customers
- products
- invoices
- receipts
- settlements
- projects

### 3. Document and asset registries

Needed strongly by:

- agro-crm
- timberdata
- kinsim

Examples:

- PDFs
- imported source files
- generated previews
- sample attachments
- simulation presets
- authored reusable component assets

### 4. Local-first configuration stores

Needed strongly by:

- kinsim
- CodexRemote

Examples:

- panel state
- view presets
- saved run configurations
- local library edits
- device-local preferences

## Proposed SharedDB Architecture

## Layer A: SharedDB Core

Owns:

- connection/config management
- migration framework
- environment resolution
- adapter contracts

Supported adapters:

- PostgreSQL
- SQLite
- file-backed JSON

## Layer B: Shared infrastructure schemas

Owns reusable tables and patterns:

- auth/session tables
- outbox/events
- job queue metadata
- document registry
- attachment metadata
- import-run metadata
- audit metadata

## Layer C: Read-model / projection toolkit

Reusable helpers for:

- canonical data + projections
- event-store to read-model building
- file import to derived views
- snapshot/export tooling

## Layer D: App-specific schemas

Each app still owns its business schema:

- agro-crm business schema
- timberdata business schema
- CodexRemote app-control schema
- kinsim simulation/config schema

## Recommended SharedDB Strategy

Do **not** build SharedDB as a single shared relational schema for every app.

Build it as:

- one shared persistence toolkit
- one shared set of infrastructure schemas
- multiple adapter options
- app-specific business schemas layered on top

## Suggested First Scope

The highest-value first scope would be:

1. shared PostgreSQL config + migration utilities
2. shared SQLite config + migration utilities
3. shared JSON/file adapter helpers
4. shared document registry model
5. shared import-run and projection helpers
6. shared audit/outbox/job metadata helpers

That would immediately help:

- agro-crm storage
- timberdata import/read-model storage
- CodexRemote app-state storage
- future SharedAuth persistence

## Relationship Between SharedUI, SharedAuth, and SharedDB

These three systems should stay separate.

### SharedUI

Owns:

- shell
- rendering
- stateful UI composition

### SharedAuth

Owns:

- identity
- authentication
- authorization
- session policy

### SharedDB

Owns:

- persistence adapters
- migrations
- shared infrastructure tables
- projection/storage toolkit

The three systems should integrate, but none of them should absorb the others.

## Recommended Next Moves

1. Treat `SharedDB` as a platform toolkit, not a universal app schema.
2. Reuse the best parts of `agro-crm` storage design as the first seed.
3. Add SQLite support patterns informed by CodexRemote.
4. Add document/import registry patterns informed by timberdata.
5. Keep file-backed/local-first storage options available for kinsim-style projects.
