# SharedUI Schema-Driven Directive for Codex v2

## Purpose

This note defines what **schema-driven design** means in the current SharedUI architecture and how Codex must apply it whenever it builds or rewrites a web app that uses SharedUI.

This version reflects the current architectural direction:

- SharedUI owns the curated standard semantic component surface
- SharedUI may internally implement that surface using shadcn-based source
- consumer apps reference only what SharedUI exposes semantically
- consumer apps may additionally register trusted custom components for app-specific needs

A SharedUI consumer app must therefore not bypass the SharedUI schema/runtime model by hand-building pages directly in raw JSX.

---

## 1) Core Rule

**If an app uses SharedUI, the app must be authored as schema-driven by default.**

That means the primary source of UI structure must be:

- dashboard state
- validators
- state policy
- layout regions
- views
- semantic component refs exposed by SharedUI
- trusted registries
- data source registrations
- action handler registrations

It must **not** be primarily authored as direct page composition in raw JSX.

---

## 2) Current SharedUI Meaning of Schema-Driven Design

In the current SharedUI architecture, schema-driven design means:

1. top-level UI structure is declared in dashboard config or preset
2. layout regions are selected through schema (`topBar`, `leftSidebar`, `main`, `rightSidebar`, etc.)
3. views are declared as schema nodes, not hardwired JSX pages
4. standard components are referenced through **SharedUI semantic component ids**
5. custom app-specific components are referenced through trusted consumer registries
6. state changes are controlled through `statePolicy`
7. every state key has a validator
8. data access is routed through registered data sources
9. actions are routed through registered action handlers
10. rendering happens through `DashboardRenderer`, not through ad hoc direct page wiring

---

## 3) What the Schema Is Allowed to Reference

The schema may reference:

### A. SharedUI standard semantic components
Examples:
- `TopNav`
- `SideNav`
- `PageHeader`
- `DataTable`
- `ConfirmDialog`
- `FilterSidebar`
- `ActionPanel`
- other semantic components intentionally exposed by SharedUI

### B. Trusted app-specific custom components
Examples:
- `PlannerSummary`
- `VatExplanationPanel`
- `AgroTable`
- `LedgerSplitEditor`

These must be mounted through a trusted registry and rendered by the SharedUI runtime.

### Not allowed as the primary schema surface
The schema must **not** directly reference raw implementation primitives such as:
- raw shadcn primitive names as the public authoring model
- arbitrary imported React components outside the trusted registry/runtime path
- hand-built page-level JSX layout as the main composition mechanism

---

## 4) SharedUI Ownership Rule

The current architectural rule is:

> SharedUI owns the curated standard semantic component surface.

That means:

- SharedUI decides which standard components exist
- SharedUI may internally implement those components using shadcn-based source
- schema authors do not choose raw shadcn primitives as the main authoring surface
- schema authors instead choose from SharedUI semantic component refs
- app authors may add trusted custom components only where SharedUI does not yet provide the needed standard surface

This is a key distinction from a model where each app directly authors its own standard UI from raw shadcn pieces.

---

## 5) What “schema-driven” means in practical file terms

A valid SharedUI app should normally include these artifacts:

- `dashboardConfig.ts`
- `dashboardPreset.json` (when presets are part of the repo workflow)
- `componentRegistry.tsx`
- `validatorRegistry.ts`
- `dataSources.ts` (if async/query-backed data is used)
- `actionHandlers.ts` (if actions/forms/confirm flows are used)

These files form the main schema/runtime integration surface.

---

## 6) Correct Split Between Schema and JSX

Schema-driven design does **not** mean “no JSX exists.”

It means:

- schema defines **composition, placement, state, and trusted references**
- JSX implements **leaf components or custom app-specific widgets**
- SharedUI semantic components are consumed by reference, not hand-composed at page level

So the correct split is:

- schema decides **what appears where**
- SharedUI exposes semantic standard components
- registries map names to trusted implementations
- JSX implements reusable leaf components, custom widgets, or SharedUI internals

Example:
- `PlannerSummary.tsx` is acceptable as a trusted custom component
- but it must be mounted via a schema node like `{ kind: "component", ref: "PlannerSummary" }`
- top-level page structure must still come from `dashboardConfig.ts` / preset, not from a hand-built JSX page

---

## 7) The Schema Surface in the Known Good Pattern

The known good pattern includes:

- `dashboardConfig.ts` declaring `state`, `statePolicy`, `layout`, `views`, and defaults
- `dashboardPreset.json` serializing the validated dashboard definition
- `componentRegistry.tsx` registering trusted custom components in addition to SharedUI/baseline exposed components
- `validatorRegistry.ts` defining explicit state validators
- `dataSources.ts` defining trusted data source registrations
- `actionHandlers.ts` defining trusted action registrations

This remains the target model.

---

## 8) What Codex Must NOT Do

When building a SharedUI consumer app, Codex must not do the following as the primary implementation pattern:

- build the app mainly as direct JSX page trees
- hardwire page layout in component files instead of the dashboard config
- bypass `DashboardRenderer`
- bypass `statePolicy`
- mutate top-level dashboard state ad hoc from random components
- fetch async data directly inside arbitrary page components when the same flow should be expressed via `dataSources.ts`
- wire actions directly in local page code when the same flow should be expressed through `actionHandlers.ts`
- use raw implementation imports as the main structural reference instead of SharedUI semantic refs or trusted registry keys
- expose raw shadcn primitives as the main schema surface for app authors

Direct JSX is allowed only for:
- trusted custom components
- small leaf implementation details
- app-specific widgets that are mounted through the schema/runtime system
- internal SharedUI implementation of semantic standard components

---

## 9) What Codex Must Do Every Time

Whenever Codex creates or rewrites a SharedUI-based web app, it must:

1. define dashboard state first
2. define validators for every state key
3. define `statePolicy` for every state key
4. define layout regions in `dashboardConfig.ts`
5. define views in schema form
6. consume standard UI through SharedUI semantic refs
7. register any app-specific custom components in `componentRegistry.tsx`
8. register data sources in `dataSources.ts` if data is needed
9. register action handlers in `actionHandlers.ts` if actions are needed
10. render through `DashboardRenderer`
11. optionally export/update a preset when the repo uses presets

---

## 10) How to Think About `dashboardConfig.ts` vs `dashboardPreset.json`

### `dashboardConfig.ts`
This is the typed authoring surface.

It is where the dashboard is usually defined in source form:
- state
- layout
- views
- defaults
- optional URL sync, auth, and other config

### `dashboardPreset.json`
This is the serialized validated dashboard representation.

It is useful for:
- portability
- validation
- round-tripping
- proving that the dashboard definition is schema-native and implementation-agnostic

Both are central to the SharedUI schema-driven model.

---

## 11) Are there many ways to do schema-driven design?

Yes, broadly speaking there are several styles of schema-driven UI in software, such as:

- JSON form schemas
- metadata-driven CRUD builders
- low-code page descriptors
- server-driven UI
- dashboard layout schemas
- config-driven component trees

But for SharedUI, Codex must use this specific repository meaning:

**typed dashboard config / preset driven composition with trusted registries, semantic SharedUI component refs, and runtime validation**

Codex must not invent another interpretation when working in SharedUI-based apps.

---

## 12) Required SharedUI Definition of Schema-Driven Design

For this project, use this exact definition:

> A SharedUI app is schema-driven when its top-level UI structure, view routing, state ownership, SharedUI semantic component references, trusted custom component registrations, data bindings, and action flows are declared through dashboard config/preset and trusted registries, and are rendered by `DashboardRenderer` rather than hand-composed directly as page JSX.

This is the repository-specific meaning that must be followed.

---

## 13) Mandatory Delivery Checklist for Codex

Every SharedUI consumer app implementation must provide or explicitly justify the absence of:

- [ ] `dashboardConfig.ts`
- [ ] `validatorRegistry.ts`
- [ ] `componentRegistry.tsx`
- [ ] `DashboardRenderer` entry point
- [ ] `statePolicy` covering all top-level state keys
- [ ] SharedUI semantic refs for standard components
- [ ] registered custom components for non-standard refs
- [ ] `dataSources.ts` if async/query-backed components exist
- [ ] `actionHandlers.ts` if forms/dialog actions exist
- [ ] `dashboardPreset.json` if the repository uses preset export/import as part of validation

If Codex cannot satisfy one of these, it must explain why before considering the work complete.

---

## 14) Review Rule for SharedUI Work

When reviewing any SharedUI-based app, ask:

1. Is the top-level layout declared in schema?
2. Are views declared in schema?
3. Are standard components referenced by SharedUI semantic key?
4. Are custom components mounted through a trusted registry?
5. Is state controlled by validators and `statePolicy`?
6. Are data flows routed through trusted registries?
7. Are actions routed through trusted handlers?
8. Is `DashboardRenderer` the composition engine?

If the answer to these is mostly “no”, then the implementation is not truly schema-driven in the SharedUI sense.

---

## 15) Suggested Instruction Block for Codex

Use this instruction block when assigning SharedUI work:

> This app must use SharedUI in its intended schema-driven form. Do not hand-compose the page structure directly in raw JSX. Define dashboard state, validators, statePolicy, layout regions, and views in `dashboardConfig.ts`; consume standard UI only through SharedUI semantic component refs; register app-specific custom components in `componentRegistry.tsx`; register async data in `dataSources.ts`; register actions in `actionHandlers.ts`; and render through `DashboardRenderer`. Any custom JSX is allowed only as trusted leaf or app-specific components mounted through the schema/runtime system. Preserve implementation-agnostic semantic refs and, where applicable, keep `dashboardPreset.json` in sync.

---

## 16) Final Rule

**If the app uses SharedUI, then SharedUI schema/runtime must be the primary composition model, and the schema must reference SharedUI’s exposed semantic component surface rather than raw shadcn primitives or hand-built page JSX.**
