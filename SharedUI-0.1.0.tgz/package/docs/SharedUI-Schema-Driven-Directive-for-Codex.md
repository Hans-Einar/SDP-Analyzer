# SharedUI Schema-Driven Directive for Codex

## Purpose

This note defines what **schema-driven design** means in the SharedUI system and how Codex must apply it whenever it builds a web app that uses SharedUI.

This directive exists because a SharedUI consumer app must not bypass the SharedUI schema/runtime model by hand-building pages directly in raw JSX.

---

## 1) Core Rule

**If an app uses SharedUI, the app must be authored as schema-driven by default.**

That means the primary source of UI structure must be:

- dashboard state
- validators
- state policy
- layout regions
- views
- semantic component refs
- trusted registries
- data source registrations
- action handler registrations

It must **not** be primarily authored as direct page composition in raw JSX.

---

## 2) What “schema-driven” means in SharedUI

In this repository, schema-driven design means:

1. UI structure is declared in a dashboard config or preset
2. layout regions are selected through schema (`topBar`, `leftSidebar`, `main`, `rightSidebar`, etc.)
3. views are declared as schema nodes, not hardwired JSX pages
4. components are referenced by trusted string keys such as `TopNav`, `SideNav`, `PageHeader`, `DataTable`
5. custom components are registered through a trusted component registry
6. state changes are controlled through `statePolicy`
7. every state key has a validator
8. data access is routed through registered data sources
9. actions are routed through registered action handlers
10. rendering happens through `DashboardRenderer`, not through ad hoc direct page wiring

---

## 3) The SharedUI Schema Surface

A valid SharedUI app should normally include these artifacts:

- `dashboardConfig.ts`
- `dashboardPreset.json` (when presets are part of the flow)
- `componentRegistry.tsx`
- `validatorRegistry.ts`
- `dataSources.ts` (if async data is used)
- `actionHandlers.ts` (if actions/forms/confirm flows are used)

These files form the main schema/runtime integration surface.

---

## 4) Example of the Intended Pattern

The known good pattern is demonstrated by the maintenance planner example:

- `dashboardConfig.ts` declares `state`, `statePolicy`, `layout`, `views`, and defaults
- `dashboardPreset.json` serializes the validated dashboard config
- `componentRegistry.tsx` extends the baseline component registry with trusted custom components
- `validatorRegistry.ts` defines explicit state validators
- `dataSources.ts` registers trusted data fetch logic by source key
- `actionHandlers.ts` registers trusted actions such as save/archive flows

This is the target pattern.

---

## 5) What is NOT allowed

When building a SharedUI consumer app, Codex must not do the following as the primary implementation pattern:

- build the app mainly as direct JSX page trees
- hardwire page layout in component files instead of the dashboard config
- bypass `DashboardRenderer`
- bypass `statePolicy`
- mutate top-level dashboard state ad hoc from random components
- fetch async data directly inside arbitrary page components when the same flow should be expressed via `dataSources.ts`
- wire actions directly in local page code when the same flow should be expressed through `actionHandlers.ts`
- use raw implementation imports as the main structural reference instead of trusted registry keys

Direct JSX is allowed only for:
- trusted custom components
- small leaf implementation details
- app-specific widgets that are mounted through the schema/runtime system

---

## 6) What Codex must do every time

Whenever Codex creates or rewrites a SharedUI-based web app, it must:

1. define dashboard state first
2. define validators for every state key
3. define `statePolicy` for every state key
4. define layout regions in `dashboardConfig.ts`
5. define views in schema form
6. register any custom components in `componentRegistry.tsx`
7. register data sources in `dataSources.ts` if data is needed
8. register action handlers in `actionHandlers.ts` if actions are needed
9. render through `DashboardRenderer`
10. optionally export/update a preset when the repo uses presets

---

## 7) Interpretation of JSX in a Schema-Driven System

Schema-driven design does **not** mean “no JSX exists.”

It means:

- JSX implements leaf components
- schema defines composition and placement

So the correct split is:

- schema decides **what appears where**
- registries map names to trusted implementations
- JSX implements the reusable or custom leaf components

Example:
- `PlannerSummary.tsx` is fine as a custom component
- but it must be mounted through a schema node like `{ kind: "component", ref: "PlannerSummary" }`

That is the intended model.

---

## 8) How to think about `dashboardConfig.ts` vs `dashboardPreset.json`

### `dashboardConfig.ts`
This is the typed authoring surface.

It is where the dashboard is usually defined in source form:
- state
- layout
- views
- defaults
- optional URL sync, auth, and other config

### `dashboardPreset.json`
This is the serialized validated dashboard representation.

It is useful for:
- portability
- validation
- round-tripping
- proving that the dashboard definition is schema-native and implementation-agnostic

So yes: these files are central to the schema-driven model.

---

## 9) Are there many ways to do schema-driven design?

Yes, broadly speaking there are several styles of schema-driven UI in software.

Examples include:

- JSON form schemas
- metadata-driven CRUD builders
- low-code page descriptors
- server-driven UI
- dashboard layout schemas
- config-driven component trees

But for SharedUI, the required style is specifically:

**typed config / preset driven dashboard composition with trusted registries and runtime validation**

So Codex should not invent a different meaning.

---

## 10) Required SharedUI Definition of Schema-Driven Design

For this project, use this exact definition:

> A SharedUI app is schema-driven when its top-level UI structure, view routing, state ownership, trusted component references, data bindings, and action flows are declared through dashboard config/preset and trusted registries, and are rendered by `DashboardRenderer` rather than hand-composed directly as page JSX.

This is the repository-specific meaning that must be followed.

---

## 11) Mandatory Delivery Checklist for Codex

Every SharedUI consumer app implementation must provide or explicitly justify the absence of:

- [ ] `dashboardConfig.ts`
- [ ] `validatorRegistry.ts`
- [ ] `componentRegistry.tsx`
- [ ] `DashboardRenderer` entry point
- [ ] `statePolicy` covering all top-level state keys
- [ ] registered custom components for non-baseline refs
- [ ] `dataSources.ts` if async/query-backed components exist
- [ ] `actionHandlers.ts` if forms/dialog actions exist
- [ ] `dashboardPreset.json` if the repository uses preset export/import as part of validation

If Codex cannot satisfy one of these, it must explain why before considering the work complete.

---

## 12) Review Rule for SharedUI Work

When reviewing any SharedUI-based app, ask:

1. Is the top-level layout declared in schema?
2. Are views declared in schema?
3. Are components referenced by semantic registry key?
4. Are custom components mounted through the registry?
5. Is state controlled by validators and `statePolicy`?
6. Are data flows routed through trusted registries?
7. Are actions routed through trusted handlers?
8. Is `DashboardRenderer` the composition engine?

If the answer to these is mostly “no”, then the implementation is not truly schema-driven.

---

## 13) Suggested Instruction Block for Codex

Use this instruction block when assigning SharedUI work:

> This app must use SharedUI in its intended schema-driven form. Do not hand-compose the page structure directly in raw JSX. Define dashboard state, validators, statePolicy, layout regions, and views in `dashboardConfig.ts`; register custom components in `componentRegistry.tsx`; register async data in `dataSources.ts`; register actions in `actionHandlers.ts`; and render through `DashboardRenderer`. Any custom JSX is allowed only as trusted leaf components mounted through the schema/runtime system. Preserve implementation-agnostic semantic refs and, where applicable, keep `dashboardPreset.json` in sync.

---

## 14) Final Rule

**If the app uses SharedUI, then SharedUI schema/runtime must be the primary composition model, not an optional layer added after a hand-built UI.**
