# SharedUI + shadcn/ui Architecture Note

## Purpose

This document describes a recommended architecture for building a reusable `SharedUI` package for multiple web applications, while using `shadcn/ui` in a clean and maintainable way.

The goal is:

- keep the same UX shell across many apps
- keep domain-specific UI out of the shared package
- avoid turning `SharedUI` into a giant component dump
- allow schema-driven UI composition where possible
- preserve flexibility for app-specific components when needed

---

## Core Recommendation

### 1. `SharedUI` should own the **application shell**, not all UI component code

`SharedUI` should provide the shared structural model:

- top bar
- left sidebar
- main content panel
- right action sidebar
- layout contracts
- state policy handling
- view registration
- persistence integration
- rendering/runtime logic for schema-driven layouts

It should **not** contain copies of all `shadcn/ui` components.

---

### 2. `shadcn/ui` code should live inside each web app, not inside `SharedUI`

This is the most important architectural rule.

`shadcn/ui` is not best treated as a traditional dependency-only component library. Its intended model is that the app owns the component code locally.

Therefore:

- each web app installs or generates the `shadcn/ui` components it needs
- those components live inside that app's source tree
- the app decides which components it exposes to its own domain views
- `SharedUI` only defines **where** views are rendered, not the internal implementation of every view

So yes: **the app loads or owns the shadcn code itself**, and `SharedUI` decides where that app-provided view is displayed.

---

## Mental Model

Think of the architecture like this:

```text
SharedUI = app shell + runtime + schema contracts
Web App = domain views + local shadcn components + domain data bindings
```

Or more formally:

```text
UI = SharedUI shell(state, layout, registry) + app-specific registered views
```

---

## Responsibility Split

### `SharedUI` responsibilities

`SharedUI` should own:

- shell layout components
- layout orchestration
- dashboard config/schema contracts
- state engine
- state policy / update rules
- panel composition
- route/state-to-view resolution
- persistence hooks/interfaces
- shared primitive wrappers if needed
- optional build-time tooling for schema/code generation

### Web app responsibilities

Each web app should own:

- its domain views
- its local `shadcn/ui` component files
- data fetching
- domain-specific tables/forms/actions
- domain-specific view registration
- app-specific schemas/config
- any extra custom UI that does not belong in the shared shell

---

## Why `shadcn/ui` should not be stored inside `SharedUI`

If all shadcn component code is placed inside `SharedUI`, several problems appear:

1. `SharedUI` becomes too large and too opinionated
2. every app inherits all component code whether it needs it or not
3. versioning becomes harder
4. customization becomes harder
5. app-specific variation becomes awkward
6. `SharedUI` stops being a reusable shell and starts becoming a monolithic UI framework

The cleaner model is:

- `SharedUI` defines structure and contracts
- each app owns the UI component code it actually uses

---

## Recommended Project Separation

A good separation looks like this:

```text
repo/
  packages/
    shared-ui/
      src/
        shell/
        runtime/
        schema/
        state/
        persistence/
        primitives/
        index.ts

  apps/
    crm/
      src/
        components/
          ui/                 # local shadcn/ui components
        views/
        schema/
        dashboard/
        data/
        app.tsx

    codex-remote/
      src/
        components/
          ui/                 # local shadcn/ui components
        views/
        schema/
        dashboard/
        data/
        app.tsx
```

---

## Recommended `SharedUI` Structure

A more detailed example for `SharedUI`:

```text
packages/shared-ui/
  src/
    shell/
      AppFrame.tsx
      TopBar.tsx
      LeftSidebar.tsx
      RightSidebar.tsx
      MainPanel.tsx

    runtime/
      renderDashboard.ts
      layoutResolver.ts
      viewRegistry.ts
      variantResolver.ts

    schema/
      contracts.ts
      validators.ts
      defaults.ts

    state/
      stateEngine.ts
      statePolicy.ts
      actions.ts

    persistence/
      UiStateStore.ts
      persistenceBridge.ts

    primitives/
      Panel.tsx
      PageHeader.tsx
      Section.tsx
      EmptyState.tsx

    index.ts
```

### Notes

- `primitives/` should only contain small shared building blocks you truly want to standardize
- `shell/` contains the actual app frame layout
- `runtime/` handles config-driven rendering
- `schema/` defines the contracts used by apps
- `state/` owns update rules and state transitions
- `persistence/` defines how UI state is saved/restored

---

## Recommended Web App Structure

Example for an app like CRM:

```text
apps/crm/
  src/
    components/
      ui/
        button.tsx
        table.tsx
        dialog.tsx
        input.tsx
        tabs.tsx

    views/
      customers/
        CustomersView.tsx
        CustomersFilters.tsx
        CustomersActions.tsx
      products/
        ProductsView.tsx
      orders/
        OrdersView.tsx

    dashboard/
      dashboardConfig.ts
      dashboardPreset.json
      viewRegistry.ts

    schema/
      customerSchema.ts
      orderSchema.ts
      productSchema.ts

    data/
      queries.ts
      commands.ts
      adapters.ts

    app.tsx
```

---

## How Rendering Should Work

The web app should register views by name, and `SharedUI` should place them into the shell.

Example idea:

```ts
const registry = {
  topBarView: TopBarView,
  leftSidebarView: LeftSidebarView,
  overviewView: OverviewView,
  formsView: FormsView,
}
```

Then the config says:

```ts
layout: {
  topBar: { view: "topBarView" },
  leftSidebar: { view: "leftSidebarView" },
  main: {
    view: "overviewView",
    variants: {
      "section=forms": { view: "formsView" }
    }
  }
}
```

Then `SharedUI` does the runtime work:

1. read state
2. resolve active layout variant
3. look up the requested view in the registry
4. render that view into the correct panel

This means:

- `SharedUI` decides **where**
- the app decides **what**

That is the key separation.

---

## Schema-Driven UI: What It Should Mean

Yes, the architecture can become strongly schema-driven.

A good model is:

- schema/config defines layout slots and view references
- schema/config defines allowed state transitions
- schema/config defines defaults and fallbacks
- domain code implements the actual views and data mapping
- registry connects schema names to actual React components

In that model, the domain code should mostly reference schema-defined objects and contracts rather than hardcoded layout wiring.

So the answer is: **yes, that is the right direction**.

But the important distinction is:

- layout should be schema-driven
- state transitions should be contract-driven
- domain rendering can be partly schema-driven
- complex business views will still need normal code

In other words, not everything should be pure JSON. The schema should drive structure and composition, not replace all implementation code.

---

## Best Practice for Domain Views

A domain view can use local app-owned shadcn components internally.

Example:

```text
CustomersView
  -> uses local Table component
  -> uses local Input component
  -> uses local Dialog component
  -> binds to customer data schema
```

`SharedUI` should not need to know any of that detail.

It only knows:

- `CustomersView` is the current main-panel view
- `CustomerActionsView` is the current right-sidebar view
- `CustomersFiltersView` is the current left-sidebar view

---

## State Persistence

`shadcn/ui` does not solve persistence. That should be part of `SharedUI` or app infrastructure.

Recommended model:

```ts
interface UiStateStore {
  load(scope: { appId: string; userId: string }): Promise<Record<string, unknown>>
  save(scope: { appId: string; userId: string }, state: Record<string, unknown>): Promise<void>
}
```

Use this for things like:

- active section
- selected row
- filter settings
- tab choice
- panel widths
- sort order
- open/closed panels

That lets a user log out and return to the same UI state later.

---

## Code Generation / Automation

Yes, build-time automation is possible, and it is a good idea.

But it should happen at **build time or scaffold time**, not at runtime.

### Good automation ideas

You can make a CLI or script such as:

```bash
npm run sharedui:sync
```

That script could:

1. read schema/config files
2. validate config
3. generate view registry boilerplate
4. generate typed contracts
5. scaffold missing view files
6. optionally install or pull shadcn components into the app
7. generate import maps

This is a good use of automation.

### What to avoid

Avoid a runtime model where the app dynamically downloads component code while the browser app is running.

That would be fragile and much harder to reason about.

---

## Optional Future Step: Custom Registry

Later, if needed, you could create your own internal registry approach.

That could mean:

- `SharedUI` publishes metadata/templates/scaffolds
- an app CLI pulls approved components into the app
- generated files land in the app's local source tree

That is much better than storing all UI code directly in `SharedUI`.

---

## Practical Rule Set

Here is the recommended rule set in plain language:

1. `SharedUI` owns layout and runtime orchestration
2. `SharedUI` does not own all shadcn component code
3. each app owns its own shadcn component files
4. each app registers domain views into `SharedUI`
5. schema/config decides where views go
6. domain views decide how data is shown
7. persistence is handled by app infrastructure or a `SharedUI` interface
8. code generation should happen at build/scaffold time, not runtime

---

## Recommended Architecture in One Sentence

**Use `SharedUI` as a schema-driven application shell and runtime, while each web app owns its local `shadcn/ui` components and domain views, and simply registers those views into the shared shell.**

---

## Final Recommendation

Start simple:

- create `SharedUI` as a normal npm package
- keep shadcn component code inside each app
- use schema/config to drive layout
- use a registry to map names to views
- add build-time code generation later

Do not begin with a highly dynamic plugin/downloader system.

Build the stable shell first. Then add automation once the contracts are proven.

---

## Short Example Flow

1. CRM app defines `dashboardConfig.ts`
2. CRM app defines `viewRegistry.ts`
3. CRM app contains local `components/ui/*` from shadcn
4. CRM app implements `CustomersView`, `OrdersView`, etc.
5. `SharedUI` reads config and current state
6. `SharedUI` resolves which views belong in top/left/main/right
7. `SharedUI` renders those views into the shared shell
8. persistence layer restores saved UI state

That gives:

- shared UX across apps
- clean separation of concerns
- good reuse
- low coupling
- freedom for app-specific UI when needed


---

## Review of Current Codex Plan and Recommended Changes

This section reviews the current Codex plan and highlights where it already aligns with the recommended architecture, and where it should be adjusted.

### Overall Assessment

The Codex plan is directionally strong in several important ways:

- it preserves a semantic renderer-facing registry instead of exposing raw shadcn primitive names
- it keeps dashboard presets implementation-agnostic
- it allows application teams to continue registering trusted custom JSX components
- it recognizes that project-specific widgets do not all belong inside SharedUI
- it aims to preserve preset compatibility, renderer contracts, and migration stability

Those are all good architectural instincts and should remain.

### Main Architectural Disagreement

The main disagreement is this:

**The Codex plan currently places shadcn/ui source ownership inside the SharedUI repository.**

That appears in multiple places, including the iteration and sprint planning notes, where the plan says to initialize shadcn/ui inside SharedUI and use locally owned shadcn source components there.

That is the part that should change.

### Recommended Correction

The preferred architecture is:

```text
SharedUI = shell + runtime + contracts + state orchestration
Consumer App = domain views + local shadcn/ui component files + app-specific bindings
```

In other words:

- SharedUI should own the application shell and rendering/runtime model
- SharedUI should not become the primary owner of copied shadcn/ui source files
- each consumer web app should own its own local shadcn/ui components
- each consumer web app should register its domain views into SharedUI
- SharedUI should decide **where** a view is rendered
- the app should decide **how** that view is implemented

This keeps SharedUI smaller, more reusable, and less likely to turn into a monolithic UI framework.

### What Should Stay From the Codex Plan

The following ideas in the Codex plan are good and should remain:

#### 1. Preserve semantic registry keys

SharedUI-facing schemas and presets should continue to use semantic ids such as:

- `TopNav`
- `SideNav`
- `PageHeader`
- `DataTable`
- `ConfirmDialog`

They should **not** expose raw implementation names such as low-level shadcn primitives.

#### 2. Keep presets implementation-agnostic

A preset should describe:

- validated dashboard config
- layout regions
- state policy
- variants
- semantic view or component references

A preset should **not** encode whether something is implemented with shadcn, Leaflet, Plotly, or another library.

#### 3. Continue supporting app-specific custom JSX components

The Codex plan is correct that special-purpose widgets should remain registerable outside SharedUI first.

Examples include:

- custom domain tables
- Leaflet maps
- Plotly charts
- topology canvases
- Codex-specific remote-control surfaces

Those should only move into SharedUI later if they prove broadly reusable.

#### 4. Prove the architecture through preview examples

The Codex plan is also correct that example dashboards and preview hosts should prove the real downstream consumption model, not just an isolated framework proof-of-concept.

### Concrete Changes Recommended To The Codex Plan

#### Change 1 - Replace “initialize shadcn/ui inside SharedUI” with an app-owned model

Any plan item that says something like:

- initialize shadcn/ui in the SharedUI repository
- rebuild SharedUI around locally owned shadcn/ui source components inside SharedUI

should be revised.

Recommended replacement wording:

> SharedUI shall not require ownership of raw shadcn/ui source files as part of its primary architecture. Instead, each consumer web app owns its local shadcn/ui source components, while SharedUI provides the schema-driven shell, semantic contracts, runtime orchestration, and view-placement model.

#### Change 2 - Separate shell components from domain views more explicitly

The plan should distinguish more clearly between:

##### SharedUI-owned shell components

Examples:

- `AppFrame`
- `TopBarRegion`
- `LeftSidebarRegion`
- `MainRegion`
- `RightSidebarRegion`
- `BottomBarRegion`

##### App-owned domain views

Examples:

- `CustomersView`
- `OrdersView`
- `ProductsView`
- `CodexSessionView`
- `MaintenancePlannerOverview`

SharedUI should mainly own shell composition and contracts, not domain-specific surface implementations.

#### Change 3 - Add build-time code generation and scaffolding explicitly

The Codex plan should add a deliberate build-time tooling phase.

Recommended addition:

- validate dashboard config and schema
- generate typed registry bindings
- scaffold missing view modules
- generate import maps or registration helpers
- optionally sync approved UI building blocks into the consumer app
- do **not** download executable component code at runtime

This is the right place for automation.

#### Change 4 - Make the preview host follow the real consumer-app structure

The Codex plan asks whether the preview host should become a lightweight shadcn consumer app.

The answer should be yes.

The preview host should use the same consumption pattern expected from downstream apps:

- local app-owned UI component source
- local domain views
- registration into SharedUI
- schema-driven layout resolution through SharedUI

That makes the preview surface a real proof of consumption rather than a special internal case.

#### Change 5 - Add a guardrail that SharedUI must not become a monolithic component dump

The plan should explicitly say that SharedUI focuses on:

- shell layout
- runtime orchestration
- schema contracts
- state handling
- persistence hooks
- a small set of carefully chosen primitives

It should avoid becoming a repository for every possible table, widget, or domain surface.

### Suggested Replacement Architecture Statement

If the Codex plan needs one concise architectural statement, use this:

> SharedUI should function as a schema-driven application shell and runtime. Consumer web applications should own their local shadcn/ui source components and domain views, and register those views into SharedUI through stable semantic contracts.

### Suggested Update To Sprint Direction

A better sprint direction would be:

1. keep SharedUI focused on shell, runtime, contracts, and state
2. keep shadcn/ui source ownership inside each consumer app
3. preserve semantic registry ids for presets and renderer contracts
4. allow trusted app-specific custom JSX components during migration and after
5. add build-time schema/code generation support
6. make the preview host behave like a real consumer app

### Final Review Summary

The Codex plan is mostly strong on semantic boundaries, preset design, and migration posture.

The main correction is to avoid making SharedUI the owner of raw shadcn/ui source as the primary architecture.

Instead:

- SharedUI should own the shell
- the app should own the local UI component source
- SharedUI should place views
- the app should implement views

That gives the cleanest separation of concerns and best matches the long-term goal of a schema-driven but still practical multi-app UI platform.
