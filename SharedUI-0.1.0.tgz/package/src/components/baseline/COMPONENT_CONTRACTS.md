# Baseline Component Contracts

This document records the shared component contract for the v1 baseline library.

## Ownership Boundary

- Shared semantic exports live in `src/components/baseline/`.
- Raw shadcn/ui source owned by this repository lives in `src/components/shadcn/`.
- Shared theme variables live in `src/styles/globals.css`.
- Presets, renderer configs, and trusted component registries continue to reference semantic SharedUI ids only.
- Raw shadcn primitive names remain internal implementation detail.

## Token Layer

Shared tokens live in `src/components/baseline/tokens.ts`.
The CSS-variable theme those tokens map to lives in `src/styles/globals.css`.

Covered token groups:
- spacing
- typography
- colors
- surfaces
- interaction states

## Navigation

### `TopNav`
- Purpose: top-level dashboard header with title, status, and optional actions.
- Constraints: use in `topBar` or other high-level shell views, not as a nested card replacement.
- Props: `title`, optional `subtitle`, optional `statusLabel`, optional `actions`.
- Variants: actionless header, status-only header, action-enabled header.
- Data shape: none.
- Example: top-bar dashboard title with preview/publish actions.
- Related: `PageHeader`, `Breadcrumbs`, `TabBar`.

### `SideNav`
- Purpose: schema-driven sidebar navigation with active-state highlighting.
- Constraints: navigation items must use dashboard state updates, not ad hoc routing.
- Props: `items`, optional `title`.
- Variants: short navigation list, multi-section list via author-provided items.
- Data shape: none.
- Example: left-sidebar navigation for overview/forms/operations.
- Related: `TabBar`, `Breadcrumbs`, `TopNav`.

### `Breadcrumbs`
- Purpose: location trail for schema-authored dashboard pages.
- Constraints: keep item count short and descriptive.
- Props: `items`.
- Variants: short or long path.
- Data shape: none.
- Example: `SharedUI / Component Library / Overview`.
- Related: `PageHeader`, `TopNav`.

### `TabBar`
- Purpose: compact in-view state navigation.
- Constraints: tabs should map to explicit dashboard-state updates.
- Props: `tabs`.
- Variants: two-tab and multi-tab bars.
- Data shape: none.
- Example: switching between overview and forms views.
- Related: `SideNav`, `DashboardLink`.

## Layout

### `PageHeader`
- Purpose: page-level title block with optional supporting action.
- Constraints: use once per main content region section.
- Props: `title`, optional `description`, optional `actionLabel`.
- Variants: informational header, call-to-action header.
- Data shape: none.
- Example: overview page with a create button.
- Related: `TopNav`, `Section`.

### `Section`
- Purpose: titled content grouping without taking over structural layout resolution.
- Constraints: do not use as a substitute for nested schema views.
- Props: `title`, optional `eyebrow`, optional `body`.
- Variants: eyebrow plus body, title-only section.
- Data shape: none.
- Example: explanatory block for renderer/runtime boundaries.
- Related: `Divider`, `PageHeader`.

### `Divider`
- Purpose: visual separation between component groups.
- Constraints: use sparingly between semantically distinct blocks.
- Props: optional `label`.
- Variants: plain divider, labeled divider.
- Data shape: none.
- Example: split layout and data-display groups in showcase views.
- Related: `Section`.

## Data Display

### `MetricCard`
- Purpose: compact KPI summary component.
- Constraints: keep content short and stable.
- Props: `title`, optional `data`.
- Variants: empty, static, data-bound.
- Data shape: `{ label: string; value: string }`.
- Example: throughput metric loaded from a data binding.
- Related: `CardSkeleton`, `ChartBlock`.

### `DataTable`
- Purpose: tabular listing for structured row data.
- Constraints: column order must be explicit and stable.
- Props: `title`, `columns`, optional `data`.
- Variants: empty, static, data-bound.
- Data shape: `Array<{ id: string; [key: string]: string }>`
- Example: operations queue table.
- Related: `TableSkeleton`, `DetailPanel`.

### `ChartBlock`
- Purpose: simple chart wrapper for low-fidelity previews and summaries.
- Constraints: this baseline version is presentational, not a full charting system.
- Props: `title`, `points`.
- Variants: short or long series.
- Data shape: `number[]`.
- Example: throughput trend preview.
- Related: `MetricCard`.

### `EmptyState`
- Purpose: zero-data or missing-integration state.
- Constraints: use for genuine absence, not as a generic error.
- Props: `title`, `message`, optional `actionLabel`.
- Variants: passive empty state, CTA empty state.
- Data shape: none.
- Example: no optional integrations configured.
- Related: `AlertBanner`, `ErrorFallback`.

### `DetailPanel`
- Purpose: labeled key/value detail rendering.
- Constraints: best for concise records, not long rich text.
- Region behavior: auto-renders as a collapsible card when mounted in `rightSidebar`.
- Props: `title`, `items`.
- Variants: short summary, denser metadata panel.
- Data shape: `Array<{ label: string; value: string }>`
- Example: owner/status summary for a component group.
- Related: `DataTable`, `Badge`.

### `Badge`
- Purpose: compact semantic state label.
- Constraints: keep labels short.
- Props: `label`, optional `tone`.
- Variants: `neutral`, `info`, `success`, `warning`, `danger`.
- Data shape: none.
- Example: stable contract badge.
- Related: `AlertBanner`, `Toast`.

### `Avatar`
- Purpose: lightweight identity marker.
- Constraints: use initials-only fallback in this baseline implementation.
- Props: `name`.
- Variants: none in v1.
- Data shape: none.
- Example: team or owner avatar chip.
- Related: `DetailPanel`.

## Inputs and Forms

### `SearchBar`
- Purpose: search input preview with simple local state.
- Constraints: this baseline component does not own filtering logic.
- Props: `title`, optional `defaultValue`, optional `placeholder`, optional `submitLabel`.
- Variants: inline search, search with preset value.
- Data shape: none.
- Example: component-library search field.
- Related: `FilterBar`, `FormBlock`.

### `FilterBar`
- Purpose: toggle-style filter selection.
- Constraints: use for compact predefined filter sets.
- Props: `title`, `options`.
- Variants: two-option or multi-option bars.
- Data shape: `Array<{ label: string; value: string }>`
- Example: all/navigation/forms filter bar.
- Related: `SearchBar`, `TabBar`.

### `FormBlock`
- Purpose: registered action-backed form submission.
- Constraints: submissions must go through a trusted `actionKey`.
- Region behavior: auto-renders as a collapsible card when mounted in `rightSidebar`.
- Props: `title`, `actionKey`, `fields`, `submitLabel`.
- Variants: short two-field forms, longer preference forms.
- Data shape: local field map submitted as action payload.
- Example: save preferences form in the showcase.
- Related: `ConfirmDialog`, `ActionPanel`.

## Feedback

### `Toast`
- Purpose: lightweight success/info feedback block.
- Constraints: this baseline version is inline, not a portal/toaster manager.
- Props: `title`, `message`, optional `tone`.
- Variants: `info`, `success`, `warning`, `danger`, `neutral`.
- Data shape: none.
- Example: library token coherence confirmation.
- Related: `AlertBanner`, `Badge`.

### `AlertBanner`
- Purpose: high-visibility inline warning, error, or information block.
- Constraints: use for durable messages, not short-lived notifications.
- Props: `title`, `message`, optional `tone`.
- Variants: `info`, `warning`, `danger`, `success`, `neutral`.
- Data shape: none.
- Example: accessibility review reminder.
- Related: `Toast`, `ErrorFallback`.

### `ConfirmDialog`
- Purpose: confirmation surface for registered destructive or state-changing actions.
- Constraints: confirmation must trigger a trusted `actionKey`.
- Props: `title`, `message`, `openLabel`, `confirmLabel`, `actionKey`.
- Variants: neutral confirm, destructive confirm depending on copy.
- Data shape: none.
- Example: archive draft confirmation.
- Related: `FormBlock`, `ActionPanel`.

### `TableSkeleton`
- Purpose: loading placeholder for data-bound tabular content.
- Constraints: use only while the actual table request is pending.
- Props: optional `label`.
- Variants: custom label or default label.
- Data shape: none.
- Example: operations queue loading state.
- Related: `DataTable`.

### `CardSkeleton`
- Purpose: loading placeholder for card-like content.
- Constraints: use only while a card request is pending.
- Props: optional `label`.
- Variants: custom label or default label.
- Data shape: none.
- Example: metric card loading state.
- Related: `MetricCard`.

### `ErrorFallback`
- Purpose: default renderer-driven error fallback component.
- Constraints: used by loader/error orchestration, not for arbitrary business warnings.
- Props: optional `title`, optional `error`.
- Variants: default renderer error, custom title renderer error.
- Data shape: none.
- Example: async data request failure.
- Related: `AlertBanner`.

## Supporting Shared Components

### `ContentPanel`
- Purpose: compatibility wrapper for a simple titled content block.
- Constraints: convenience component used by the example dashboards.
- Props: `title`, `body`.
- Variants: body-only content panel.
- Data shape: none.
- Example: login required or access denied copy block.
- Related: `Section`.

### `OperationsToolbar`
- Purpose: example-specific toolbar component for local-state-driven filters.
- Constraints: tied to the static dashboard example’s `reportFilter` local state.
- Props: none.
- Variants: none in v1.
- Data shape: local view state.
- Example: week/month/broken filter toggles.
- Related: `FilterBar`.

### `ActionPanel`
- Purpose: example-facing action status block built on top of the shared action runtime.
- Constraints: requires a trusted `actionKey`.
- Region behavior: auto-renders as a collapsible card when mounted in `rightSidebar`.
- Props: `title`, `actionKey`, `buttonLabel`, optional `payload`.
- Variants: success and failure action paths.
- Data shape: none.
- Example: complete review / restricted mutation actions.
- Related: `FormBlock`, `ConfirmDialog`.

### `TopBarTitle`
- Purpose: compatibility wrapper for `TopNav`.
- Constraints: prefer `TopNav` for new schema authoring.
- Props: `title`, optional `subtitle`.
- Variants: title-only or title-plus-subtitle.
- Data shape: none.
- Example: first dashboard top bar.
- Related: `TopNav`.

### `SidebarList`
- Purpose: compatibility wrapper for `SideNav`.
- Constraints: prefer `SideNav` for new schema authoring.
- Props: `items`.
- Variants: none beyond the supplied items.
- Data shape: `Array<{ label: string; set: Record<string, unknown> }>`
- Example: first dashboard left sidebar.
- Related: `SideNav`.

## Trusted Custom JSX Expectations

Trusted registered custom JSX components should follow the same documentation standard wherever practical:
- purpose
- constraints
- props
- variants
- expected data shape
- examples
- related components

Additional rules for trusted custom JSX components:
- register them by stable trusted key in the same renderer registry contract as shared components
- do not bypass dashboard structural resolution or variant logic
- do not assume unrestricted writes to dashboard state
- prefer consuming shared tokens or shared wrappers so custom additions do not drift visually

## Preview Support

Current preview surfaces:
- `src/examples/staticDashboardBaseline`
- `src/examples/componentLibraryShowcase`
